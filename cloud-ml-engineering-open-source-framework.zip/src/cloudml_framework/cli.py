
import argparse, json
from .pipeline import train_and_evaluate
def main():
    p=argparse.ArgumentParser(description="Reproducible tabular ML training CLI")
    p.add_argument("--data",required=True); p.add_argument("--target",required=True)
    p.add_argument("--output",default="outputs"); p.add_argument("--test-size",type=float,default=.2)
    p.add_argument("--seed",type=int,default=42); a=p.parse_args()
    if not .1 <= a.test_size <= .5: p.error("--test-size must be between 0.1 and 0.5")
    m=train_and_evaluate(a.data,a.target,a.output,a.test_size,a.seed)
    print(json.dumps({"accuracy":m["accuracy"],"rows":m["rows"],"features":m["features"]},indent=2))
if __name__=="__main__": main()
