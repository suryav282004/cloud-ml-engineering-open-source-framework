
import json, logging
from pathlib import Path
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

def train_and_evaluate(csv_path, target, output_dir="outputs", test_size=0.2, random_state=42):
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s",
                        handlers=[logging.StreamHandler(), logging.FileHandler(out/"run.log", mode="w")], force=True)
    path = Path(csv_path)
    if not path.exists(): raise FileNotFoundError(f"CSV not found: {path}")
    df = pd.read_csv(path)
    if df.empty or target not in df.columns: raise ValueError("Dataset empty or target column missing.")
    df = df.dropna(subset=[target])
    if df[target].nunique() < 2: raise ValueError("Target must contain at least two classes.")
    X, y = df.drop(columns=[target]), df[target]
    if X.shape[1] == 0: raise ValueError("No feature columns.")
    nums = X.select_dtypes(include="number").columns.tolist()
    cats = X.select_dtypes(exclude="number").columns.tolist()
    transformers = []
    if nums:
        transformers.append(("num", Pipeline([("impute",SimpleImputer(strategy="median")),("scale",StandardScaler())]), nums))
    if cats:
        transformers.append(("cat", Pipeline([("impute",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore"))]), cats))
    pre = ColumnTransformer(transformers)
    model = Pipeline([("preprocess",pre),("classifier",LogisticRegression(max_iter=1000,class_weight="balanced"))])
    stratify = y if y.value_counts().min() >= 2 else None
    Xtr, Xte, ytr, yte = train_test_split(X,y,test_size=test_size,random_state=random_state,stratify=stratify)
    logging.info("Training rows=%d, features=%d",len(Xtr),X.shape[1])
    model.fit(Xtr,ytr); pred=model.predict(Xte)
    metrics={"model":"LogisticRegression","rows":int(len(df)),"features":int(X.shape[1]),"target":target,
             "test_size":test_size,"random_state":random_state,"accuracy":float(accuracy_score(yte,pred)),
             "classification_report":classification_report(yte,pred,output_dict=True,zero_division=0),
             "confusion_matrix":confusion_matrix(yte,pred).tolist()}
    joblib.dump(model,out/"model.joblib")
    (out/"metrics.json").write_text(json.dumps(metrics,indent=2))
    pd.DataFrame({"actual":yte.to_numpy(),"predicted":pred}).to_csv(out/"predictions.csv",index=False)
    logging.info("Accuracy=%.4f",metrics["accuracy"])
    logging.info("Saved model, metrics and predictions to %s",out)
    return metrics
