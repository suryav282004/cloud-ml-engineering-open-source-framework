
import argparse
from pathlib import Path
import joblib, pandas as pd
def main():
    p=argparse.ArgumentParser(); p.add_argument("--model",default="outputs/model.joblib")
    p.add_argument("--input",required=True); p.add_argument("--output",default="outputs/new_predictions.csv"); a=p.parse_args()
    model=joblib.load(a.model); frame=pd.read_csv(a.input); frame["prediction"]=model.predict(frame)
    Path(a.output).parent.mkdir(parents=True,exist_ok=True); frame.to_csv(a.output,index=False)
    print("Saved:",a.output)
if __name__=="__main__": main()
