
# Cloud ML Engineering: Open-Source Analytics Framework

A reproducible Python framework for tabular machine learning. It validates CSV input, preprocesses numeric and categorical features, trains a baseline classifier, evaluates it, and saves reusable artifacts.

## Features
- Numeric median imputation and standardization
- Categorical imputation and one-hot encoding
- Reproducible train/test split
- Logistic Regression baseline
- Accuracy, classification report and confusion matrix
- Saved model, metrics, predictions and run log
- CLI training and prediction commands
- Unit test and notebook demo

## Setup
Python 3.9+ recommended.
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

## Train
```bash
python -m cloudml_framework.cli --data data/customer_purchase_sample.csv --target purchased --output outputs
```

## Predict new records
```bash
python -m cloudml_framework.predict --model outputs/model.joblib --input data/new_customers_sample.csv --output outputs/new_predictions.csv
```

## Test
```bash
pytest -q
```

## Outputs
`outputs/model.joblib`, `metrics.json`, `predictions.csv`, and `run.log`.

## Cloud extension
See `docs/aws_deployment_guide.md`. This repository is a local starter project; it does not provision AWS resources or claim a cloud deployment. Review costs, IAM permissions and security before deploying.

## Certification
A GitHub project or course completion badge is not a professional certification. A certification requires passing the official provider exam. See `docs/certification_study_plan.md`.
