
# Architecture

CSV -> validation -> train/test split -> preprocessing -> Logistic Regression -> evaluation -> model/metrics/predictions/log artifacts -> prediction CLI.

Numeric features use median imputation and standard scaling. Categorical features use most-frequent imputation and one-hot encoding. Preprocessing is fitted inside a scikit-learn Pipeline on training data to reduce data leakage. A fixed seed makes the split reproducible.

Production extensions: schema validation, experiment tracking, model registry, drift monitoring, authentication, encryption, secrets management, CI/CD, load testing and rollback.
