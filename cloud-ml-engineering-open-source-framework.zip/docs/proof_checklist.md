
# Activity proof checklist

## Open-source framework
- [ ] Public GitHub repository URL
- [ ] README, source code, requirements and tests
- [ ] Successful training terminal screenshot
- [ ] outputs/metrics.json, predictions.csv and run.log
- [ ] Passing pytest screenshot
- [ ] Cloud deployment evidence only if actually deployed

## Certification
- [ ] Official certification name and exam code
- [ ] Official digital badge or credential URL
- [ ] Issue date and credential ID if provided

Do not claim a certification before passing the official exam.
