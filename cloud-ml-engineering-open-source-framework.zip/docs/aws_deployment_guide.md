
# AWS deployment learning guide

This is a learning guide, not proof of a completed cloud deployment.

1. Store versioned training data in a private Amazon S3 bucket.
2. Use IAM roles with least privilege; never commit access keys.
3. Adapt the training entry point for Amazon SageMaker AI training jobs.
4. Store model artifacts in S3 and register approved versions in SageMaker Model Registry.
5. Deploy to a SageMaker real-time endpoint or batch transform.
6. Monitor logs, endpoint metrics, data quality and model quality.
7. Add CI/CD tests and an approval gate before production deployment.

Create a budget alert before provisioning resources. Encrypt storage, avoid sensitive data in samples, and delete unused endpoints after testing.
